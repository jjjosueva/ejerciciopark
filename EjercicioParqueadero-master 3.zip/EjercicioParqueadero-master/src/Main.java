import java.awt.image.ShortLookupTable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

/*public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int opc,horall,salidac;
        String placa;
        Carro cr= null;

        Parqueadero pq =new Parqueadero();

        List<Parqueadero> parqueaderos=new ArrayList<Parqueadero>();


        do {




            System.out.println("1.Ingrese un carro al parqueadero");
            System.out.println("2.Salida de un carro");
            System.out.println("3.Informe de ingresos del parqueadero");
            System.out.println("4.Consultar la cantidad de puestos disponibles");
            System.out.println("5.Avanzar el reloj del parqueadero");
            System.out.println("6.Cambiar la tarifa del parqueadero ");
            System.out.println("7.Salir");
            opc = Integer.parseInt(sc.next());


            switch (opc) {

                case 1: {
                    int Puesto=0;
                    System.out.println("Imgrese el numero de placa");
                    placa=sc.next();
                    System.out.println("Ingrese hora de llegada");
                    horall=sc.nextInt();
                    System.out.println(""+pq.entrarCarro(placa));
                    cr = new Carro(placa,horall);


                    System.out.println("La hora de llegada es"+cr.darHoraLlegada());



                }
                break;
                case 2:{
                          System.out.println("Ingrese la placa de su carro");
                          placa= sc.next();
                          System.out.println("Ingrese la hora de salida de su carro:");
                          salidac=sc.nextInt();
                          System.out.println("su tiempo fue de: "+cr.darTiempoEnParqueadero(salidac));



                        System.out.println("El valor a pagar es: "+pq.sacarCarro(placa));
                        System.out.println();
                        System.out.println("Su carro ha salido");
                         System.out.println(""+pq.hayCarroMasDeOchoHoras());








                 }break;


                case 3:{
                    Puesto[] puestos;
                    puestos = new Puesto[40];
                    for( int i = 0; i < 40; i++ )
                        puestos[ i ] = new Puesto( i );


                    for( int i = 0; i < 40; i++ )
                        System.out.println("\nIngresos al parqueadero: "+pq.darPlacaCarro(i));;
                    System.out.println("\nIngresos al parqueadero :"+pq.calcularPuestosLibres());



                    {




                    }










                }break;

                case 4:{
                    System.out.println("La cantidad de puestos disponibles son "+pq.calcularPuestosLibres());


                }break;

                case 5:{
                    System.out.println("Hora actual:  "+pq.darHoraActual());
                    pq.avanzarHora();
                    System.out.println("Hora adelantada:  "+pq.darHoraActual());



                }break;
                case 7:{
                    imprimirCArros((ArrayList<Parqueadero>) parqueaderos);




                }break;

                case 6:{
                    int tarifa;
                    System.out.println("\nLa tarifa actual es: "+pq.darTarifa());
                    System.out.println("\nIngrese la nueva tarifa");
                    tarifa=sc.nextInt();
                    pq.cambiarTarifa(tarifa);
                    System.out.println("\nLa nueva taria es "+pq.darTarifa());




                }break;
                case 8:{
                    System.out.println("El promedio es"+pq.darTiempoPromedio());





                }break;




            }
        }while (opc!=9);


    }

    public static void ingresarCarro(ArrayList<Carro>lista){

        String placa;
        int horall;

         Scanner sc = new Scanner(System.in);
        System.out.println("Imgrese el numero de placa");
        placa=sc.next();
        System.out.println("Ingrese hora de llegada");
        horall=sc.nextInt();
        lista.add(new Carro(placa,horall));




    }



    public static void imprimirCArros(ArrayList<Parqueadero>lista){
        Iterator<Parqueadero> it= lista.iterator();
        while (it.hasNext()){
            System.out.println(it.next());

        }







    }



}*/