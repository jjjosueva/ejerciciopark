import java.util.ArrayList;
import java.util.Scanner;

public class Main2 {

    public static void main(String[] args) {
        int opc;
        String placa;
        Carro cr = null;

        Parqueadero pq = new Parqueadero();
        ArrayList<Carro> listaCarros = new ArrayList<>();

        Scanner sc = new Scanner(System.in);

        do {
            System.out.println("1. Ingrese un carro al parqueadero");
            System.out.println("2. Salida de un carro");
            System.out.println("3. Informe de ingresos del parqueadero");
            System.out.println("4. Consultar la cantidad de puestos disponibles");
            System.out.println("5. Avanzar el reloj del parqueadero");
            System.out.println("6. Cambiar la tarifa del parqueadero");
            System.out.println("7. Lista de carros con mas de 3 horas");
            System.out.println("8.Tiempo Promedio ");
            System.out.println("9.Carro ms de 8 Horas");
            System.out.println("10.Hay mas carros de 8 Horas");
            System.out.println("11.Carros con placa igual");
            System.out.println("12.Carros con placa PB");
            System.out.println("13.Carro mas de 24Horas");
            System.out.println("14.Cantidad de carro con placa Pb mas de 24H");
            System.out.println("15.Desocupar Estacionamiento");
            System.out.println("16.Cantidad de carros para sacar ");
            opc = Integer.parseInt(sc.next());

            switch (opc) {
                case 1:
                    System.out.println("Ingrese el número de placa");
                    placa = sc.next();
                    System.out.println(pq.entrarCarro(placa));
                    cr = new Carro(placa, pq.darHoraActual());
                    listaCarros.add(cr);
                    break;

                case 2:
                    System.out.println("Ingrese la placa de su carro");
                    placa = sc.next();
                    System.out.println("Ingrese la hora de salida de su carro:");
                    int salida = sc.nextInt();
                    System.out.println("Su tiempo fue de: " + cr.darTiempoEnParqueadero(salida));
                    System.out.println("El valor a pagar es: " + pq.sacarCarro(placa));
                    System.out.println("Su carro ha salido");

                    break;

                case 3:
                    System.out.println("Ingresos al parqueadero: " + pq.darMontoCaja());
                    System.out.println("Cantidad de puestos libres: " + pq.calcularPuestosLibres());
                    break;

                case 4:
                    System.out.println("La cantidad de puestos disponibles son " + pq.calcularPuestosLibres());
                    break;

                case 5:
                    System.out.println("Hora actual: " + pq.darHoraActual());
                    pq.avanzarHora();
                    System.out.println("Hora adelantada: " + pq.darHoraActual());
                    break;

                case 6:
                    System.out.println("La tarifa actual es: " + pq.darTarifa());
                    System.out.println("Ingrese la nueva tarifa");
                    int tarifa = sc.nextInt();
                    pq.cambiarTarifa(tarifa);
                    System.out.println("La nueva tarifa es " + pq.darTarifa());
                    break;


                case 7: {
                    ArrayList<Carro> carrosMasDeTresHoras = pq.darCarrosMasDeTresHorasParqueados();

                    if (carrosMasDeTresHoras.isEmpty()) {
                        System.out.println("No hay carros parqueados por más de tres horas.");
                    } else {
                        System.out.println("Carros parqueados por más de tres horas:");
                        for (Carro carro : carrosMasDeTresHoras) {
                            System.out.println("Placa: " + carro.darPlaca() + ", Tiempo en parqueadero: " + carro.darTiempoEnParqueadero(pq.darHoraActual()) + " horas");
                        }
                    }
                }
                break;

                case 8:
                    double tiempoPromedio = pq.darTiempoPromedio();
                    System.out.println("El tiempo promedio de los carros en el parqueadero es: " + tiempoPromedio + " horas");
                    break;


                case 9:
                    Carro carroMasLargo = pq.darCarroMasDeOchoHoras();
                    if (carroMasLargo != null) {
                        System.out.println("El carro que ha estado más tiempo (más de 8 horas) en el parqueadero es:");
                        System.out.println("Placa: " + carroMasLargo.darPlaca());
                        System.out.println("Tiempo en parqueadero: " + carroMasLargo.darTiempoEnParqueadero(pq.darHoraActual()) + " horas");
                    } else {
                        System.out.println("No hay ningún carro que haya estado más de 8 horas en el parqueadero.");
                    }
                    break;





                case 10:
                    if (pq.hayCarroMasDeOchoHoras()) {
                        System.out.println("Hay al menos un carro que ha estado parqueado por más de 8 horas.");
                    } else {
                        System.out.println("No hay carros que hayan estado parqueados por más de 8 horas.");
                    }
                    break;

                case 11:
                    if (pq.hayCarrosPlacaIgual()) {
                        System.out.println("Hay al menos dos carros parqueados con la misma placa.");
                    } else {
                        System.out.println("No hay carros parqueados con la misma placa.");
                    }
                    break;

                case 12:
                    int carrosConPlacaPB = pq.contarCarrosQueComienzanConPlacaPB();
                    System.out.println("Número de carros con placa que comienza con \"PB\": " + carrosConPlacaPB);
                    break;

                case 13:
                    if (pq.hayCarroCon24Horas()) {
                        System.out.println("Hay al menos un carro que lleva 24 o más horas parqueado.");
                    } else {
                        System.out.println("No hay carros que lleven 24 o más horas parqueados.");
                    }
                    break;

                case 14:
                    String mensajeMetodo1 = pq.metodo1();
                    System.out.println(mensajeMetodo1);
                    break;

                case 15:
                    int carrosSacados = pq.desocuparParqueadero();
                    System.out.println("Se han sacado " + carrosSacados + " carros del parqueadero.");
                    break;
                case 16:
                    String mensajeMetodo2 = pq.metodo2();
                    System.out.println(mensajeMetodo2);
                    break;








            }
        } while (opc != 17);
    }


}
